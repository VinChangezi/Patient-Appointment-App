package com.example.aman.hospitalappointy.qrcode;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.example.aman.hospitalappointy.R;
import com.example.aman.hospitalappointy.feedback.FeedbackActivity;
import com.example.aman.hospitalappointy.home.HomeActivity;

public class ScannerActivity extends AppComponentFactory {

    private TextView mName, mEmail;
    private EditText mFeedbackText;
    private Button mSubmitFeedback;

    private String currnetUID;

//    private FirebaseAuth mAuth = FirebaseAuth.getInstance();
//    private DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner);
    }

}
